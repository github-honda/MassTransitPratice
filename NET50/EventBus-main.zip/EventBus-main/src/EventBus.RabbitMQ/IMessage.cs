﻿namespace EventBus.RabbitMQ
{
    public interface IMessage
    {
        string Text { get; }
    }
}