﻿namespace EventBus.InMemory
{
    public interface IMessage
    {
        string Text { get; }
    }
}