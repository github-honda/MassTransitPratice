# EventBus
> Exemplo de mensageria, utilizando C# e .NET 5, através do framework [MassTransit](https://masstransit-project.com/) integrado ao RabbitMQ e Amazon SQS/SNS.
