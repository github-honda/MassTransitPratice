﻿namespace MyCompany.Domains
{
	public interface ICustomerRepository
    {
		void Save(Customer customer);
    }
}
